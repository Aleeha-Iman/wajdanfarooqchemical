 let slideIndex = 0;
 function changeSlide(n) {
        const slides = document.querySelector('.slides');
        const totalSlides = document.querySelectorAll('.slide').length;

        slideIndex += n; if (slideIndex >= totalSlides) {
            slideIndex = 0;
        } else if (slideIndex < 0) {
            slideIndex = totalSlides - 1;
        }  // Calculate the new translateX value
        const translateX = -slideIndex * 100; // Each slide takes 100%
        slides.style.transform = `translateX(${translateX}%)`; // Move the slides
    }
     // Auto slide every 3 seconds
    setInterval(() => changeSlide(1), 3000);   
$(document).ready(function() {
  $('.product-filter ul li a').on('click', function() {
    var filter = $(this).data('filter');
    $('.product-list .product').hide();
    $('.product-list .product.' + filter).show();
  });
});